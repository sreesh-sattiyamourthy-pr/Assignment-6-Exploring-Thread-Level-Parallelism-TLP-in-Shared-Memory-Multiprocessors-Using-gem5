#!/usr/bin/env python3
import os
import subprocess
from pathlib import Path

# ======================
# Configuration
# ======================
gem5_bin = "build/X86/gem5.opt"
se_script = "configs/deprecated/example/se.py"
binary = "tests/test-progs/daxpy/bin/x86/linux/daxpy_mt"  # multi-threaded daxpy
minor_file = Path("src/cpu/minor/MinorCPU.py")
backup_file = minor_file.with_suffix(".bak")

# FloatSimdFU variants (opLat + issueLat = 7)
latency_pairs = [(1,6),(2,5),(3,4),(4,3),(5,2),(6,1)]

# Number of threads / cores to test
thread_counts = [2, 4, 8]

# Backup original MinorCPU.py if not already done
if not backup_file.exists():
    subprocess.run(["cp", str(minor_file), str(backup_file)])

results = []

# ======================
# Run all variants on multiple cores
# ======================
for opLat, issueLat in latency_pairs:
    # Modify MinorCPU.py for FloatSimdFU
    with open(backup_file) as f:
        lines = f.readlines()

    new_lines = []
    inside_fu = False
    for line in lines:
        stripped = line.strip()
        if "FloatSimdFU" in stripped:
            inside_fu = True
        if inside_fu and "opLat=" in stripped:
            line = f"        opLat={opLat},\n"
        if inside_fu and "issueLat=" in stripped:
            line = f"        issueLat={issueLat},\n"
            inside_fu = False
        new_lines.append(line)

    with open(minor_file, "w") as f:
        f.writelines(new_lines)

    # Rebuild gem5
    subprocess.run(["scons", gem5_bin, "-j4"], stdout=subprocess.DEVNULL)

    for threads in thread_counts:
        print(f"\n--- Running daxpy_mt with opLat={opLat}, issueLat={issueLat}, Threads={threads} ---")
        
        # Set environment variable for threads in C binary
        os.environ["OMP_NUM_THREADS"] = str(threads)  # optional if using OpenMP, for pthreads it's fixed in code

        # Output directory
        outdir = f"m5out_op{opLat}_iss{issueLat}_t{threads}"
        subprocess.run([gem5_bin, "--outdir=" + outdir, se_script, "--cmd=" + binary])

        # Parse stats
        stats_file = Path(outdir) / "stats.txt"
        ipc = "NA"
        cycles = "NA"
        if stats_file.exists():
            with open(stats_file) as sf:
                for line in sf:
                    if "system.cpu.ipc" in line:
                        ipc = line.split()[1]
                    if "simTicks" in line:
                        cycles = line.split()[1]

        results.append((opLat, issueLat, threads, ipc, cycles))
        print(f"Results: IPC={ipc}, Cycles={cycles}")

# Restore original MinorCPU.py
subprocess.run(["cp", str(backup_file), str(minor_file)])
print("\nOriginal MinorCPU.py restored.")

# ======================
# Print results table
# ======================
print("\nFinal results table:")
print("| opLat | issueLat | Threads | IPC | Cycles |")
print("| ----- | -------- | ------- | --- | ------ |")
for op, iss, thr, ipc, cyc in results:
    print(f"| {op}     | {iss}        | {thr}       | {ipc}   | {cyc}      |")
