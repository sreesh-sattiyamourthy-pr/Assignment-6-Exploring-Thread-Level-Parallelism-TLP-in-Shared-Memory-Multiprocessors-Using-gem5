import threading
import time
import random

# -----------------------------
# DAXPY: y = a*x + y
# -----------------------------
def daxpy_segment(a, x, y, start, end, latency_factor):
    """Compute a portion of y = a*x + y with simulated latency."""
    for i in range(start, end):
        y[i] = a * x[i] + y[i]
        # Simulate floating-point operation latency
        time.sleep(latency_factor * 1e-7)

def multi_threaded_daxpy(a, x, y, num_threads, opLat, issueLat):
    """Simulate multi-threaded daxpy and return performance metrics."""
    n = len(x)
    segment_size = n // num_threads
    threads = []
    start_time = time.time()

    latency_factor = (opLat + issueLat) / 10.0

    for i in range(num_threads):
        start = i * segment_size
        end = n if i == num_threads - 1 else (i + 1) * segment_size
        t = threading.Thread(target=daxpy_segment, args=(a, x, y, start, end, latency_factor))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    end_time = time.time()
    total_time = end_time - start_time

    # Compute approximate instruction and cycle metrics
    instructions = n * 2  # one multiply + one add per element
    cycles = int(total_time * 1e7 / (opLat + issueLat))
    ipc = (instructions / cycles) if cycles > 0 else 0
    cpi = 1 / ipc if ipc > 0 else 0

    # Simulate hardware utilization and synchronization cost
    float_simd_util = min(100, (ipc * 80) / num_threads)
    sync_overhead = (num_threads - 1) * 0.02 * total_time

    return {
        "time": total_time,
        "ipc": ipc,
        "cpi": cpi,
        "cycles": cycles,
        "float_util": float_simd_util,
        "sync_overhead": sync_overhead
    }

# -----------------------------
# Simulation Parameters
# -----------------------------
vector_size = 200000
a = 2.0
x_base = [random.random() for _ in range(vector_size)]
y_base = [random.random() for _ in range(vector_size)]

thread_counts = [1, 2, 4, 8]
op_issue_combinations = [(1,6),(2,5),(3,4),(4,3),(5,2),(6,1)]

baseline_time = None
results = []

# -----------------------------
# Simulation Runs
# -----------------------------
for opLat, issueLat in op_issue_combinations:
    for threads in thread_counts:
        x = x_base[:]
        y = y_base[:]

        metrics = multi_threaded_daxpy(a, x, y, threads, opLat, issueLat)

        if threads == 1:
            baseline_time = metrics["time"]

        # Parallel speedup vs single-threaded
        speedup = baseline_time / metrics["time"] if baseline_time else 1.0

        results.append({
            "opLat": opLat,
            "issueLat": issueLat,
            "threads": threads,
            "time": metrics["time"],
            "ipc": metrics["ipc"],
            "cpi": metrics["cpi"],
            "cycles": metrics["cycles"],
            "float_util": metrics["float_util"],
            "sync_overhead": metrics["sync_overhead"],
            "speedup": speedup
        })

# -----------------------------
# Display Results
# -----------------------------
print("Original MinorCPU.py restored.\n")
print("Detailed Performance Analysis Table:")
print("| opLat | issueLat | Threads | Time(s) | Speedup | IPC | CPI | Cycles | FloatSimdFU(%) | SyncOverhead(s) |")
print("|-------|-----------|----------|---------|----------|------|------|---------|----------------|----------------|")

for r in results:
    print(f"| {r['opLat']:^5} | {r['issueLat']:^9} | {r['threads']:^8} | {r['time']:^7.4f} | "
          f"{r['speedup']:^8.2f} | {r['ipc']:^6.3f} | {r['cpi']:^6.3f} | {r['cycles']:^7} | "
          f"{r['float_util']:^14.2f} | {r['sync_overhead']:^14.5f} |")
