#include <stdio.h>
#define N 1024

float x[N], y[N];
float a = 2.5;

void daxpy_chunk(int start, int end) {
    for (int i = start; i < end; i++) {
        y[i] = a * x[i] + y[i];
    }
}

int main(int argc, char *argv[]) {
    int num_cores = 4;
    if (argc > 1) num_cores = atoi(argv[1]);
    int chunk = N / num_cores;

    for (int i = 0; i < N; i++) {
        x[i] = i * 1.0;
        y[i] = i * 2.0;
    }

    for (int c = 0; c < num_cores; c++) {
        int start = c * chunk;
        int end = (c == num_cores - 1) ? N : (c + 1) * chunk;
        daxpy_chunk(start, end);
    }

    for (int i = 0; i < 5; i++)
        printf("y[%d] = %f\n", i, y[i]);

    return 0;
}
