#!/usr/bin/env python3
import os
import subprocess
from pathlib import Path

# ======================
# Configuration
# ======================
gem5_bin = "build/X86/gem5.opt"
se_script = "configs/deprecated/example/se.py"
minor_file = Path("src/cpu/minor/MinorCPU.py")
backup_file = minor_file.with_suffix(".bak")

latency_pairs = [(1,6),(2,5),(3,4),(4,3),(5,2),(6,1)]
thread_counts = [2,4,8]
results = []

# ======================
# Step 1: Write multi-threaded daxpy C code
# ======================
c_code = """
#include <stdio.h>
#include <stdlib.h>
#define N 10000000

float x[N], y[N];
float a = 2.5;

void daxpy_chunk(int start, int end) {
    for (int i = start; i < end; i++) {
        y[i] = a * x[i] + y[i];
    }
}

int main(int argc, char *argv[]) {
    int num_cores = 4;
    if (argc > 1) num_cores = atoi(argv[1]);
    int chunk = N / num_cores;

    for (int i = 0; i < N; i++) {
        x[i] = i * 1.0;
        y[i] = i * 2.0;
    }

    for (int c = 0; c < num_cores; c++) {
        int start = c * chunk;
        int end = (c == num_cores - 1) ? N : (c + 1) * chunk;
        daxpy_chunk(start, end);
    }

    // Print first 5 elements as verification
    for (int i = 0; i < 5; i++)
        printf("y[%d] = %f\\n", i, y[i]);

    return 0;
}
"""

# Write C file
os.makedirs("tests/test-progs/daxpy/bin/x86/linux", exist_ok=True)
c_file = Path("tests/test-progs/daxpy/daxpy_multicore.c")
binary = Path("tests/test-progs/daxpy/bin/x86/linux/daxpy_multicore")
with open(c_file, "w") as f:
    f.write(c_code)

# Compile
print("Compiling daxpy_multicore.c...")
subprocess.run(["gcc", "-O2", str(c_file), "-o", str(binary)])

# ======================
# Step 2: Backup MinorCPU.py
# ======================
if not backup_file.exists():
    subprocess.run(["cp", str(minor_file), str(backup_file)])

# ======================
# Step 3: Run gem5 for all opLat/issueLat/thread combinations
# ======================
for opLat, issueLat in latency_pairs:

    # Modify MinorCPU.py
    with open(backup_file) as f:
        lines = f.readlines()
    new_lines = []
    inside_fu = False
    for line in lines:
        stripped = line.strip()
        if "FloatSimdFU" in stripped:
            inside_fu = True
        if inside_fu and "opLat=" in stripped:
            line = f"        opLat={opLat},\n"
        if inside_fu and "issueLat=" in stripped:
            line = f"        issueLat={issueLat},\n"
            inside_fu = False
        new_lines.append(line)
    with open(minor_file, "w") as f:
        f.writelines(new_lines)

    # Rebuild gem5
    print(f"Building gem5 for opLat={opLat}, issueLat={issueLat}...")
    subprocess.run(["scons", gem5_bin, "-j4"], stdout=subprocess.DEVNULL)

    for threads in thread_counts:
        print(f"\n--- Running daxpy_multicore with opLat={opLat}, issueLat={issueLat}, Threads={threads} ---")

        outdir = f"m5out_op{opLat}_iss{issueLat}_t{threads}"
        subprocess.run([gem5_bin, "--outdir=" + outdir, se_script,
                        "--cmd=" + str(binary), "--options=" + str(threads)],
                        stdout=subprocess.DEVNULL)

        # Parse stats
        stats_file = Path(outdir) / "stats.txt"
        ipc_total = 0.0
        cycles = "NA"

        if stats_file.exists():
            with open(stats_file) as sf:
                for line in sf:
                    line = line.strip()
                    # MinorCPU FloatSimdFU instructions and busy cycles
                    for cpu_id in range(threads):
                        if line.startswith(f"system.cpu{cpu_id}.fu_float_simd.inst_count"):
                            inst_count = float(line.split()[1])
                        if line.startswith(f"system.cpu{cpu_id}.fu_float_simd.busy_cycles"):
                            busy_cycles = float(line.split()[1])
                            if busy_cycles > 0:
                                ipc_total += inst_count / busy_cycles
                    # Total simulation cycles
                    if line.startswith("sim_ticks"):
                        cycles = line.split()[1]

        avg_ipc = round(ipc_total / threads, 6) if ipc_total > 0 else "NA"
        results.append((opLat, issueLat, threads, avg_ipc, cycles))
        print(f"Results: Avg IPC={avg_ipc}, Cycles={cycles}")

# ======================
# Step 4: Restore MinorCPU.py
# ======================
subprocess.run(["cp", str(backup_file), str(minor_file)])
print("\nOriginal MinorCPU.py restored.")

# ======================
# Step 5: Print final table
# ======================
print("\nFinal results table:")
print("| opLat | issueLat | Threads | IPC | Cycles |")
print("| ----- | -------- | ------- | --- | ------ |")
for op, iss, thr, ipc, cyc in results:
    print(f"| {op}     | {iss}        | {thr}       | {ipc}   | {cyc}      |")
